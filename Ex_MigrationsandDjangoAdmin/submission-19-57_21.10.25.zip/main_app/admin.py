from django.contrib import admin

from .models import EventRegistration

# Register your models here.

@admin.register(EventRegistration)
class EventRegistrationAdmin(admin.ModelAdmin):
    list_display = ('event_name', 'participant_name', 'registration_date')
    search_fields = ('event_name', 'participant_name')
    list_filter = ('registration_date', 'event_name')
